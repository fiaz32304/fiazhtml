import express from "express"
import mongoose from "mongoose"
import dotenv from "dotenv"
import bodyparser from "body-parser"
import route from "./routes/userRoute.js";
import cors from "cors"

const app =express();
app.use(bodyparser.json());
app.use(cors());
dotenv.config();

const PORT =process.env.PORT || 7000;
const MONGOURL=process.env.MONGO_URL;

mongoose
        .connect(MONGOURL)
        .then(()=>{
            console.log("MongoDB connected succesfully.")
            app.listen(PORT,()=>{
                console.log(`server is running on port ${PORT}`);
            });
            })
            .catch((err)=> console.log(err));
        
app.use("/api",route);